# 🚒 BFP 911 PH - Region 1

This is the **BFP 911 PH** Android App focused on **Region 1**.

## 📌 How to Build on GitHub
1. Create a new repo on GitHub.
2. Upload this project (all files).
3. Go to **Actions** tab → enable workflows.
4. After a few minutes, download APKs from **Artifacts**:
   - `BFP911PH-debug-apk` → install on your phone.
   - `BFP911PH-release-apk` → signed (if keystore secrets added).

## 🔑 Release Signing (Optional)
1. Generate a keystore:  
   ```sh
   keytool -genkeypair -v -keystore bfp911ph.keystore -keyalg RSA -keysize 2048 -validity 10000 -alias bfp911ph
   ```
2. Encode in base64:  
   ```sh
   base64 bfp911ph.keystore > keystore_base64.txt
   ```
3. Add GitHub Secrets:
   - `KEYSTORE_BASE64`
   - `KEYSTORE_PASSWORD`
   - `KEY_ALIAS`
   - `KEY_PASSWORD`
4. Workflow will build signed release APK automatically.
